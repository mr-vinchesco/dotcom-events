import AsyncStorage from '@react-native-async-storage/async-storage';

const STORAGE_KEYS = {
  SHEETS_CONFIG: '@dotcom_events_sheets_config',
  SCAN_HISTORY: '@dotcom_events_scan_history',
  APP_SETTINGS: '@dotcom_events_app_settings',
};

export const StorageService = {
  // Google Sheets Configuration
  async saveSheetsConfig(config) {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.SHEETS_CONFIG, JSON.stringify(config));
      return true;
    } catch (e) {
      console.error('Error saving sheets config:', e);
      return false;
    }
  },

  async getSheetsConfig() {
    try {
      const value = await AsyncStorage.getItem(STORAGE_KEYS.SHEETS_CONFIG);
      return value ? JSON.parse(value) : null;
    } catch (e) {
      console.error('Error loading sheets config:', e);
      return null;
    }
  },

  async clearSheetsConfig() {
    try {
      await AsyncStorage.removeItem(STORAGE_KEYS.SHEETS_CONFIG);
      return true;
    } catch (e) {
      return false;
    }
  },

  // Scan History (local log)
  async addScanToHistory(scanResult) {
    try {
      const history = await this.getScanHistory();
      const newEntry = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        ...scanResult,
      };
      const updated = [newEntry, ...history].slice(0, 200); // Keep last 200 scans
      await AsyncStorage.setItem(STORAGE_KEYS.SCAN_HISTORY, JSON.stringify(updated));
      return newEntry;
    } catch (e) {
      console.error('Error saving scan history:', e);
      return null;
    }
  },

  async getScanHistory() {
    try {
      const value = await AsyncStorage.getItem(STORAGE_KEYS.SCAN_HISTORY);
      return value ? JSON.parse(value) : [];
    } catch (e) {
      return [];
    }
  },

  async clearScanHistory() {
    try {
      await AsyncStorage.removeItem(STORAGE_KEYS.SCAN_HISTORY);
      return true;
    } catch (e) {
      return false;
    }
  },
};

export default StorageService;
