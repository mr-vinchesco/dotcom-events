// DotCom Events - Brand Colors & Theme
export const Colors = {
  // Primary
  turquoise: '#0ABFBC',
  turquoiseLight: '#3DD6D3',
  turquoiseDark: '#089A97',
  turquoiseSubtle: '#E0F8F7',

  // Neutrals
  white: '#FFFFFF',
  offWhite: '#F5F7F8',
  lightGrey: '#E8ECEF',
  midGrey: '#9AA5B1',
  darkGrey: '#2D3142',
  darkerGrey: '#1A1E2E',
  charcoal: '#1A1A2E',

  // Status
  success: '#27AE60',
  successLight: '#D5F5E3',
  warning: '#F39C12',
  warningLight: '#FEF9E7',
  error: '#E74C3C',
  errorLight: '#FDEDEC',
  info: '#0ABFBC',

  // Backgrounds
  background: '#F5F7F8',
  surface: '#FFFFFF',
  cardBg: '#FFFFFF',
};

export const Typography = {
  fontSizes: {
    xs: 11,
    sm: 13,
    md: 15,
    lg: 17,
    xl: 20,
    xxl: 24,
    xxxl: 30,
    display: 38,
  },
  fontWeights: {
    regular: '400',
    medium: '500',
    semiBold: '600',
    bold: '700',
    extraBold: '800',
  },
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const BorderRadius = {
  sm: 6,
  md: 12,
  lg: 18,
  xl: 24,
  full: 999,
};

export const Shadows = {
  small: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 3,
  },
  medium: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 6,
  },
  large: {
    shadowColor: '#0ABFBC',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 10,
  },
};
